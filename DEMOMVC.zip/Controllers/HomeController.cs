﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using KMApp.Service;
using PagedList;
using KMApp.Models;

namespace KMApp.Controllers
{
    public class HomeController : Controller
    {

        public ActionResult Index(string sortOrder, string currentFilter, string searchString, int? page)
        {
            DBService dBService = new DBService();
            var products = dBService.GetProducts();

            ViewBag.Categories = dBService.GetCategories();

            int pageSize = 3;
            int pageNumber = (page ?? 1);
            return View(products.ToPagedList(pageNumber, pageSize));
        }

        public ActionResult AddUpdate(int ProductId)
        {

            DBService dBService = new DBService();
            Product product = new Product();
            if (ProductId > 0)
            {
                product = dBService.GetProductById(ProductId);
            }
            
            ViewBag.Categories = dBService.GetCategories();
            return View(product);
        }

        [HttpPost]
        public ActionResult AddUpdate(Product product)
        {
            DBService dBService = new DBService();
            dBService.SaveProduct(product);
            ViewBag.Categories = dBService.GetCategories();
            return RedirectToAction("Index");
        }
        public ActionResult Privacy()
        {
            return View();
        }

        
    }
}